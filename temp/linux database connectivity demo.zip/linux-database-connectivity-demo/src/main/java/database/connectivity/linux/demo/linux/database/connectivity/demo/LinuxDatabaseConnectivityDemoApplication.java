package database.connectivity.linux.demo.linux.database.connectivity.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinuxDatabaseConnectivityDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinuxDatabaseConnectivityDemoApplication.class, args);
	}

}
