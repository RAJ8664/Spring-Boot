package database.connectivity.linux.demo.linux.database.connectivity.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinuxDatabaseConnectivityDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
